package lesson4;

public class fourthElement{

		static int findKthSmallest(int[] arr, int n, int k)

		{

		

			int max = 0;

			for (int i = 0; i < n; i++)

			{

				if (arr[i] > max)

					max = arr[i];

			}

		

			int[] counter = new int[max + 1];

			

			int smallest = 0;

			

			for (int i = 0; i < n; i++)

			{

				counter[arr[i]]++;

			}

			

			for (int num = 1; num <= max; num++)

			{

				if (counter[num] > 0)

				{

					smallest += counter[num];

				}

				if (smallest >= k)

				{

					// smallest element

					return num;

				}

			}

			return -1;

		}

	

		public static void main(String[] args)

		{

		

			int[] arr = { 10, 9, 4, 6, 20, 14, 5 };

			int N = arr.length;

			int K = 4;

		System.out.print(findKthSmallest(arr, N, K));

		}
	}

